<?php

	class DB_settings{
		const host = 'localhost';
		const user = 'root';
		const pass = 'root';
		const database = 'Projekt';
	}